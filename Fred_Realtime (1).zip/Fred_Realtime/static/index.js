// Arquivo: index.js

// Função para criar um toast
function criarToast(mensagem) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerText = mensagem;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('show');
    }, 100);

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

// Função para salvar os dados no Local Storage
function salvarNoLocalStorage(idCliente, status, nome_cliente) {
    const historicoStatus = JSON.parse(localStorage.getItem('historicoStatus')) || {};
    historicoStatus[idCliente || 'autorizacao_usuario'] = status;
    localStorage.setItem('historicoStatus', JSON.stringify(historicoStatus));
    criarToast(`Status do cliente ${nome_cliente} atualizado para: ${status}`);
}

// Função para enviar os dados ao servidor
async function enviarDados(idCliente, status, nome_cliente) {
    try {
        const response = await fetch('/atualizar-status', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: idCliente,
                status: status,
                nome: nome_cliente
            })
        });

        if (response.ok) {
            console.log('Status atualizado com sucesso!');
            criarToast(`Status do cliente ${idCliente} atualizado para: ${status}`);
        } else {
            console.error('Falha ao atualizar o status.');
            criarToast('Falha ao atualizar o status. Tente novamente.');
        }
    } catch (error) {
        console.error('Erro ao enviar dados:', error);
        criarToast('Erro ao enviar dados. Verifique sua conexão.');
    }
}

// Função para atualizar a exibição de status no histórico
function atualizarStatusNaTela() {
    document.querySelectorAll('li').forEach(item => {
        const status = item.getAttribute('data-status');
        const statusText = item.querySelector('.status-text');
        const wrapperButton = item.querySelector('.wraper_button');

        if (status) {
            if (status === 'autorizado') {
                statusText.textContent = 'Cliente autorizado';
                statusText.classList.add('status-autorizado');
            } else if (status === 'Não autorizado') {
                statusText.textContent = 'Cliente não autorizado';
                statusText.classList.add('status-nao-autorizado');
            }
            // Ocultar os botões se o status já existe
            wrapperButton.style.display = 'none';
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
    atualizarStatusNaTela(); // Chamar a função para inicializar o status na tela

    // Referência ao modal e botões
    const modal = document.getElementById('confirmationModal');
    const confirmationMessage = document.getElementById('confirmationMessage');
    const confirmButton = document.getElementById('confirmButton');
    const cancelButton = document.getElementById('cancelButton');

    let pendingAction = null;

    // Função para abrir o modal
    function abrirModal(mensagem, action) {
        confirmationMessage.innerHTML = `<span class="alert-text">ATENÇÃO:</span> ${mensagem}`;
        modal.style.display = 'flex';
        pendingAction = action;
    }
    
    // Fechar o modal sem ação
    cancelButton.addEventListener('click', () => {
        modal.style.display = 'none';
        pendingAction = null;
    });

    // Confirmar a ação
    confirmButton.addEventListener('click', () => {
        if (pendingAction) {
            pendingAction();
        }
        modal.style.display = 'none';
        pendingAction = null;
    });

    // Botões de autorização
    document.querySelectorAll('.autorizado').forEach(button => {
        button.addEventListener('click', function () {
            const idCliente = this.closest('li').getAttribute('data-id');
            const nomeCliente = this.closest('li').querySelector('span:nth-of-type(3)').nextSibling.nodeValue.trim();

            abrirModal(`Deseja confirmar a entrada de ${nomeCliente}?`, () => {
                salvarNoLocalStorage(idCliente, 'autorizado', nomeCliente);
                enviarDados(idCliente, 'autorizado', nomeCliente);
                this.closest('.wraper_button').style.display = 'none';
                const statusText = this.closest('li').querySelector('.status-text');
                statusText.textContent = 'Cliente autorizado';
                statusText.classList.add('status-autorizado');
            });
        });
    });

    document.querySelectorAll('.nao_autorizado').forEach(button => {
        button.addEventListener('click', function () {
            const idCliente = this.closest('li').getAttribute('data-id');
            const nomeCliente = this.closest('li').querySelector('span:nth-of-type(3)').nextSibling.nodeValue.trim();

            abrirModal(` Deseja confirmar que ${nomeCliente} não está autorizado?`, () => {
                salvarNoLocalStorage(idCliente, 'Não autorizado', nomeCliente);
                enviarDados(idCliente, 'Não autorizado', nomeCliente);
                this.closest('.wraper_button').style.display = 'none';
                const statusText = this.closest('li').querySelector('.status-text');
                statusText.textContent = 'Cliente não autorizado';
                statusText.classList.add('status-nao-autorizado');
            });
        });
    });

    // Recuperando os dados do Local Storage e setando o status dos clientes na tela de histórico
    const historicoStatus = JSON.parse(localStorage.getItem('historicoStatus')) || {};
    document.querySelectorAll('li').forEach(item => {
        const idCliente = item.getAttribute('data-id');
        if (historicoStatus[idCliente]) {
            item.classList.add(historicoStatus[idCliente]);
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {
    atualizarStatusNaTela(); // Inicializa a exibição de status


    const statusFilter = document.getElementById('statusFilter');
    statusFilter.addEventListener('change', function () {
        filtrarAtendimentosPorStatus(this.value);
    });

    function filtrarAtendimentosPorStatus(status) {
        document.querySelectorAll('#clientes-list li').forEach(item => {
            const itemStatus = item.getAttribute('data-status'); // Obtém o status do item
            const wrapperButton = item.querySelector('.wraper_button'); // Obtém os botões de ação
    
            // Mapear os valores do filtro para o atributo data-status
            let statusMap = {
                all: 'all',
                aguardando: 'aguardando',
                autorizado: 'autorizado',
                nao_autorizado: 'Não autorizado'
            };
    
            // Verifica se o status corresponde ao filtro selecionado
            if (status === 'all' || itemStatus === statusMap[status]) {
                item.style.display = 'block'; // Mostra o item
    
                // Exibe os botões apenas para itens "aguardando"
                if (itemStatus === 'aguardando' && wrapperButton) {
                    wrapperButton.style.display = 'flex';
                } else if (wrapperButton) {
                    wrapperButton.style.display = 'none';
                }
            } else {
                item.style.display = 'none'; // Oculta o item
    
                // Sempre oculta os botões de itens filtrados
                if (wrapperButton) {
                    wrapperButton.style.display = 'none';
                }
            }
        });
    }
});
